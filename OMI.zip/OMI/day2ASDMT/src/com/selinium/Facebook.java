package com.selinium;

import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ById;
import org.openqa.selenium.By.ByName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Facebook {
public static void main(String[] args) throws InterruptedException {
	Random rm=new Random(10000000);
	int at=rm.nextInt();

	
	System.setProperty("webdriver.chrome.driver","D:\\OMI\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	String url="https://www.facebook.com";
	
		String exptitile = "facebook";
		String actualtile = "";
		driver.get(url);
        
			/*
			 * driver.findElement(ByName.name("email")).sendKeys("jundare.onkar12@gmail.com"
			 * );
			 * driver.findElement(ByName.name("pass")).sendKeys(Integer.toString(rm.nextInt(
			 * ))); driver.findElement(ById.id("u_0_2")).submit();
			 */
		driver.findElement(ByName.name("firstname")).sendKeys("Prasad");
		driver.findElement(ById.id("u_0_o")).sendKeys("Gopal");
		driver.findElement(ById.id("u_0_r")).sendKeys("prasad@gmail.com");
		driver.findElement(ById.id("u_0_u")).sendKeys("prasad@gmail.com");
		driver.findElement(ById.id("u_0_w")).sendKeys("Prasad@123");
		driver.findElement(ById.id("day")).sendKeys("15");
		driver.findElement(ById.id("month")).sendKeys("01");
		driver.findElement(ById.id("year")).sendKeys("1994");
		WebElement radiobtn=driver.findElement(ById.id("u_0_7"));
		radiobtn.click();
		driver.findElement(ById.id("u_0_13")).click();
		Thread.sleep(11000);
		driver.findElement(By.linkText("Didn't get a code?")).click();
		Thread.sleep(3000);
		driver.findElement(By.linkText("No longer have access to these?")).click();
		Thread.sleep(3000);
		driver.findElement(ById.id("u_0_d")).click();
		Thread.sleep(3000);
		driver.findElement(ById.id("pass")).sendKeys("Prasad@123");
		Thread.sleep(3000);
	

				
        
}
}
