package test_enums;

public class Test {
	enum Colors {
		RED,GREEN,BLUE
	}
	public static void main(String[] args) {
		Colors c=Colors.BLUE;
	}
}
